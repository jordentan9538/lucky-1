# 🎡 Lucky Wheel Backend API

Node.js + Express backend for a Lucky Wheel game.

## Endpoints
- `GET /health` — health check
- `GET /api/spin` — spin and get a prize
- `POST /api/score` — submit score `{ "user": "Alice", "score": 120 }`
- `GET /api/scores` — leaderboard

## Local Run
```bash
npm install
npm start
# http://localhost:3000
```

## Deploy to Render (Blueprint)
1. Push this folder to a GitHub repo.
2. Open Render → **New → Blueprint** → select the repo.
3. Deploy. Done!
