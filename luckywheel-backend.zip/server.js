import express from "express";
import cors from "cors";
import bodyParser from "body-parser";

const app = express();
app.use(cors());
app.use(bodyParser.json());

// ====== In-memory store (reset on restart) ======
let scores = [];

// ====== Health Check ======
app.get("/health", (req, res) => {
  res.send("OK");
});

// ====== 🎡 Spin API ======
app.get("/api/spin", (req, res) => {
  const prizes = [
    "🍎 Apple",
    "🍌 Banana",
    "🍇 Grape",
    "🍒 Cherry",
    "💎 Diamond",
    "🎁 Gift"
  ];
  const prize = prizes[Math.floor(Math.random() * prizes.length)];
  res.json({ prize, ts: Date.now() });
});

// ====== 🏆 Submit score ======
app.post("/api/score", (req, res) => {
  const { user, score } = req.body;

  if (!user || typeof score !== "number") {
    return res.status(400).json({ error: "Missing user or score" });
  }

  const entry = { user, score, time: Date.now() };
  scores.push(entry);
  res.json({ message: "Score saved!", entry });
});

// ====== 📊 Leaderboard ======
app.get("/api/scores", (req, res) => {
  const sorted = [...scores].sort((a, b) => b.score - a.score);
  res.json(sorted);
});

// ====== Start server ======
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Lucky Wheel backend running on http://localhost:${PORT}`);
});
